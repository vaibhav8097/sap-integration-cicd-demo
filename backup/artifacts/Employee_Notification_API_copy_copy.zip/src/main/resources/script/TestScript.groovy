import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    def company = message.getProperty("CompanyCode")
    def email   = message.getProperty("SupportEmail")

    message.setHeader("X-Company", company)
    message.setHeader("X-Email", email)

    return message
}